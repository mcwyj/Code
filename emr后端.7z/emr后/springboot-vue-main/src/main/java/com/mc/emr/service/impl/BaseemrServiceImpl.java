package com.mc.emr.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mc.emr.entity.BaseEmr;
import com.mc.emr.mapper.BaseemrMapper;
import com.mc.emr.service.BaseemrService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author mc
 * @since 2024-04-01
 */
@Service
public class BaseemrServiceImpl extends ServiceImpl<BaseemrMapper, BaseEmr> implements BaseemrService {

    @Resource
    private BaseemrMapper baseemrMapper;
    @Override
    public int saveBaseEmr(BaseEmr baseEmr, int type) {
        int max=baseemrMapper.selectMaxId();
        baseEmr.setEmrId(max+1);
        baseEmr.setType(type);
        return baseemrMapper.insert(baseEmr);
    }

    @Override
    public int deleteByBaseId(Integer id) {
        return baseemrMapper.deleteById(id);
    }
}
