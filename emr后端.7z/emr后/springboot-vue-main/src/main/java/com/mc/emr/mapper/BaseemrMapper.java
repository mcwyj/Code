package com.mc.emr.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mc.emr.entity.BaseEmr;
import org.apache.ibatis.annotations.Select;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author mc
 * @since 2024-04-01
 */
public interface BaseemrMapper extends BaseMapper<BaseEmr> {
    @Select("select MAX(emrid) from base_emr")
    int selectMaxId();
}
