package com.mc.emr.service;

import java.security.NoSuchAlgorithmException;

public interface DigitalSignatureService {
    String generateDigitalSignature(String data) throws Exception;
    boolean verifyDigitalSignature(String data, String digitalSignature) throws Exception;
}

