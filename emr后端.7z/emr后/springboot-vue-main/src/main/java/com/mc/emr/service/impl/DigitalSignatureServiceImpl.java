package com.mc.emr.service.impl;

import com.mc.emr.entity.KeyPairHolder;
import com.mc.emr.service.DigitalSignatureService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.security.*;
import java.util.Base64;

@Service
public class DigitalSignatureServiceImpl implements DigitalSignatureService {
    @Resource
    private KeyPairHolder keyPairHolder;

    @Override
    public String generateDigitalSignature(String data) throws Exception {
        PrivateKey privateKey = keyPairHolder.getPrivateKey();
        Signature signature = Signature.getInstance("SHA256withRSA");
        signature.initSign(privateKey);
        signature.update(data.getBytes());
        byte[] signatureBytes = signature.sign();
        return Base64.getEncoder().encodeToString(signatureBytes);
    }

    @Override
    public boolean verifyDigitalSignature(String data, String digitalSignature) throws Exception {
        PublicKey publicKey = keyPairHolder.getPublicKey();
        Signature verifier = Signature.getInstance("SHA256withRSA");
        verifier.initVerify(publicKey);
        verifier.update(data.getBytes());
        byte[] signatureBytes = Base64.getDecoder().decode(digitalSignature);
        return verifier.verify(signatureBytes);
    }
}
