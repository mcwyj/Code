package com.mc.emr.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 *
 * </p>
 *
 * @author mc
 * @since 2024-03-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="Emr对象", description="")
public class Emr implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.ASSIGN_ID)
    private Integer id;

    private String date;

    private String time;

    private String name;

    private String symptom;

    private String now;

    private String ever;

    private String physical;

    private String inspect;

    private String dia;

    private String solve;

    private String ps;

    @TableField("checkcode")
    private String checkCode;

    public String toStringExceptCode() {
        return "Emr{" +
                "id=" + id +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", name='" + name + '\'' +
                ", symptom='" + symptom + '\'' +
                ", now='" + now + '\'' +
                ", ever='" + ever + '\'' +
                ", physical='" + physical + '\'' +
                ", inspect='" + inspect + '\'' +
                ", dia='" + dia + '\'' +
                ", solve='" + solve + '\'' +
                ", ps='" + ps + '\'' +
                '}';
    }
}
