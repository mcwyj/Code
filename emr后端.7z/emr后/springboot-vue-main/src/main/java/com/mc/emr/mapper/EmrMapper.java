package com.mc.emr.mapper;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.mc.emr.entity.Emr;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author mc
 * @since 2024-03-23
 */
@Mapper
public interface EmrMapper extends BaseMapper<Emr> {

    @Select("select emr.* from emr join base_emr on emr.id=base_emr.emrid ${ew.customSqlSegment} ")
    List<Emr> selectListJoinEmrAndBaseEmr(@Param(Constants.WRAPPER) QueryWrapper<Emr> queryWrapper);
    @Select("select MAX(id) from emr")
    int selectMaxId();
}
