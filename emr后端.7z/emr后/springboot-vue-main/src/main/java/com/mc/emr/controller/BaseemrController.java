package com.mc.emr.controller;


import com.mc.emr.common.Constants;
import com.mc.emr.common.Result;
import com.mc.emr.entity.BaseEmr;
import com.mc.emr.entity.Emr;
import com.mc.emr.mapper.BaseemrMapper;
import com.mc.emr.service.BaseemrService;
import com.mc.emr.service.EmrService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author mc
 * @since 2024-04-01
 */
@CrossOrigin
@RestController
@RequestMapping("/emr/baseemr")
public class BaseemrController {
    @Resource
    BaseemrService baseemrService;

    @PostMapping("/saveBaseEmr")
    public Result saveBaseEmr(@RequestBody BaseEmr baseEmr,int type){
        if(baseemrService.saveBaseEmr(baseEmr,type) != 0){
            return Result.success();
        }else{
            return Result.error(Constants.CODE_400,"名称不能为空");
        }
    }
    @DeleteMapping("/deleteByBaseId")
    public Result deleteById(Integer id){
        if(baseemrService.deleteByBaseId(id) != 0){
            return Result.success();
        }else{
            return Result.error(Constants.CODE_400,"名称不能为空");
        }
    }
}

