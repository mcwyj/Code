package com.mc.emr.controller;

import com.mc.emr.service.DigitalSignatureService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;


@CrossOrigin
@RestController
@RequestMapping("/emr/record")
public class RecordController {
    @Resource
    private DigitalSignatureService digitalSignatureService;

    @GetMapping("/sign")
    public String signData(String data) throws Exception {
        return digitalSignatureService.generateDigitalSignature(data);
    }

    @GetMapping("/verify")
    public boolean verifySignature(String data) throws Exception {
        String digitalSignature="Qt7OnYzGCp48xHg+4KDP8dfufT7IYzxBW+DbTl4enWN8eAie0roIEiZMJJEOqVkHAMZkJyIdD5sP4tNM9M/63PTBoiDWJEnejXH8G414NcF4ZOzsxdHfvFNweZgr6vUnJsD9lKHEGVBLuwtiZ7/dQh81K1W/U+U0B9Wc+0Kul1cOWvXMDEozOjvirIzdVPG0oLCDbZBg4CjqZXr1jy0mtS3WWvtYylAxVMJVtgnVOsQenb75jlzWfU7oWzodIPD2COjWaF+UHdZ598I1cth8dE0UzQEB1z2qJBoVsSsXa2+iZ379dCqd/CxhBGP1A0gTRtncOwloLCGlvp43CB0t0g==";
        return digitalSignatureService.verifyDigitalSignature(data,digitalSignature);
    }

}
