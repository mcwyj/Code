package com.mc.emr.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.mc.emr.entity.Emr;
import com.mc.emr.mapper.BaseemrMapper;
import com.mc.emr.mapper.EmrMapper;
import com.mc.emr.service.DigitalSignatureService;
import com.mc.emr.service.EmrService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author mc
 * @since 2024-03-23
 */
@Service
public class EmrServiceImpl extends ServiceImpl<EmrMapper, Emr> implements EmrService {
    @Resource
    private EmrMapper emrMapper;
    @Resource
    private BaseemrMapper baseemrMapper;
    @Resource
    private DigitalSignatureService digitalSignatureService;
    @Override
    public List<Emr> getAllEmr(){
        QueryWrapper<Emr> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("id", "date", "time", "name", "symptom", "now", "ever", "physical", "inspect", "dia", "solve", "ps");
        return emrMapper.selectList(queryWrapper);
    }

    @Override
    public List<Emr> getEmrBy(String context,int type,String date,String radio,int flag) throws Exception {
        QueryWrapper<Emr> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("emr.id", "emr.date", "emr.time", "emr.name", "emr.symptom", "emr.now", "emr.ever", "emr.physical", "emr.inspect", "emr.dia", "emr.solve", "emr.ps")
                .like("emr.name", context);

        if(type==0||type==1)
            queryWrapper.eq("base_emr.type", type);
        if(!Objects.equals(date, ""))
            queryWrapper.eq(StringUtils.isNotBlank(date),"emr.date",date);
        if(flag==1){
            queryWrapper.eq("patientId",radio);
        }
        else if(flag==2){
            queryWrapper.eq("doctor",radio);
        }
        else if(flag==3){
            queryWrapper.eq("department",radio);
        }
        return this.selectListSecurity(queryWrapper,1);
    }

    @Override
    public int saveEmr(Emr emr) throws Exception {
        int max=emrMapper.selectMaxId();
        emr.setId(max+1);
        emr.setCheckCode(digitalSignatureService.generateDigitalSignature(emr.toStringExceptCode()));
        return emrMapper.insert(emr);
    }

    @Override
    public List<Emr> todayEmr() throws Exception {

        QueryWrapper<Emr> queryWrapper = new QueryWrapper<>();
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        queryWrapper.eq("date",formatter.format(date));
        return this.selectListSecurity(queryWrapper,0);
    }

    @Override
    public int deleteById(Integer id) {
        return emrMapper.deleteById(id);
    }

    @Override
    public List<Emr> getPatientEmr(Integer patientId, Integer target) throws Exception {
        QueryWrapper<Emr> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("patientId",patientId);
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String sDate=formatter.format(date);
        String sStartDate;
        if(target==1){
            queryWrapper.eq("date",sDate);
        }
        else if(target==2){
            sStartDate=sDate.substring(0,8)+"01";
            queryWrapper.ge("date",sStartDate);
            queryWrapper.le("date",sDate);
        }
        else if(target==3){
            sStartDate=sDate.substring(0,5)+"01-01";
            queryWrapper.ge("date",sStartDate);
            queryWrapper.le("date",sDate);
        }
        queryWrapper.orderByDesc("date");
        return this.selectListSecurity(queryWrapper,1);
    }

    @Override
    public int[] getEveryYearCount() {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy");
        String sDate=formatter.format(date);
        int[] res = new int[100];
        int allYear;
        QueryWrapper<Emr> queryWrapper = new QueryWrapper<>();
        queryWrapper.orderByAsc("date").last("limit 1");
        Emr minEmr=emrMapper.selectOne(queryWrapper);
        int minYear=Integer.parseInt(minEmr.getDate().substring(0,4));
        allYear=Integer.parseInt(sDate)-minYear;
        res[0]=allYear;
        for(int i=0;i<=allYear;i++){
            QueryWrapper<Emr> emrQueryWrapper = new QueryWrapper<>();
            emrQueryWrapper.ge("date",String.valueOf(minYear+i));
            emrQueryWrapper.le("date",String.valueOf(minYear+i+1));
            res[i+1]=emrMapper.selectCount(emrQueryWrapper);
        }
        return res;
    }

    @Override
    public int[] getEveryMonthCount(int year) {
        int[] res = new int[12];
        QueryWrapper<Emr> queryWrapper = new QueryWrapper<>();
        queryWrapper.like("date",String.valueOf(year));
        List<Emr> nowYearEmr=emrMapper.selectList(queryWrapper);
        for(Emr emr: nowYearEmr){
            res[Integer.parseInt(emr.getDate().substring(5,7))-1]++;
        }
        return res;
    }

    @Override
    public int[] getDiseasesCount(String startYear, String endYear, String[] diseases) {
        int n=diseases.length;
        int[] res = new int[n];
        for(int i=0;i<n;i++) {
            QueryWrapper<Emr> queryWrapper = new QueryWrapper<>();
            queryWrapper.like("name",diseases[i]);
            queryWrapper.ge("date",startYear);
            queryWrapper.le("date",String.valueOf(Integer.parseInt(endYear)+1));
            res[i]=emrMapper.selectCount(queryWrapper);
        }
        return res;
    }

    @Override
    public int updateCode() throws Exception {
        QueryWrapper<Emr> queryWrapper = new QueryWrapper<>();
        queryWrapper.le("id",974);
        List<Emr> updateEmr=emrMapper.selectList(queryWrapper);
        for(Emr emr:updateEmr){
            emr.setCheckCode(digitalSignatureService.generateDigitalSignature(emr.toStringExceptCode()));
            emrMapper.updateById(emr);
        }
        return 0;
    }

    public List<Emr> selectListSecurity(QueryWrapper<Emr> queryWrapper,int key) throws Exception {
        List<Emr> allEmrs;
        int flag=0;
        if(key==0){
            allEmrs=emrMapper.selectList(queryWrapper);
        }
        else{
            allEmrs=emrMapper.selectListJoinEmrAndBaseEmr(queryWrapper);
        }
        for(Emr emr:allEmrs){
            if(!digitalSignatureService.verifyDigitalSignature(emr.toStringExceptCode(),emr.getCheckCode())){
                System.out.println("数据库被威胁了");
                flag=1;
            }
        }
        if(flag==1){
            allEmrs.get(0).setId(-1);
        }
        return allEmrs;
    }
}
