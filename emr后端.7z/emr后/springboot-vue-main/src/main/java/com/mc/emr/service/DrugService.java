package com.mc.emr.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mc.emr.entity.Drug;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author mc
 * @since 2024-04-12
 */
public interface DrugService extends IService<Drug> {

    List<Drug> getAllDrug();

    Integer getDrugCount();
}
