package com.mc.emr.controller;


import com.mc.emr.common.Constants;
import com.mc.emr.common.Result;
import com.mc.emr.entity.Emr;
import com.mc.emr.service.DigitalSignatureService;
import com.mc.emr.service.EmrService;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author mc
 * @since 2024-03-23
 */
@CrossOrigin
@RestController
@RequestMapping("/emr/emr")

public class EmrController {

    @Resource
    EmrService emrService;



    @GetMapping("/getAllEmr")
    public Result getAllEmr() throws Exception {
        return Result.success(emrService.getAllEmr());
    }

    @GetMapping("/getEmrBy")
    public Result getEmrBy(String context,int type,String date,String radio,int flag) throws Exception {
        return Result.success(emrService.getEmrBy(context,type,date,radio,flag));
    }
    @PostMapping("/saveEmr")
    public Result saveEmr(@RequestBody Emr emr) throws Exception {
        if(emrService.saveEmr(emr) != 0){
            return Result.success();
        }else{
            return Result.error(Constants.CODE_400,"添加失败");
        }
    }
    @GetMapping("/todayEmr")
    public  Result todayEmr() throws Exception {
        return Result.success(emrService.todayEmr());
    }
    @DeleteMapping("/deleteById")
    public Result deleteById(Integer id){
        if(emrService.deleteById(id) != 0){
            return Result.success();
        }else{
            return Result.error(Constants.CODE_400,"名称不能为空");
        }
    }
    @GetMapping("/getPatientEmr")
    public  Result getPatientEmr(Integer patientId,Integer target) throws Exception {
        return Result.success(emrService.getPatientEmr(patientId,target));
    }
    @GetMapping("/getEveryYearCount")
    public Result getEveryYearCount(){
        return Result.success(emrService.getEveryYearCount());
    }
    @GetMapping("/getEveryMonthCount")
    public  Result getEveryMonthCount(int year){
        return Result.success(emrService.getEveryMonthCount(year));
    }
    @GetMapping("/getDiseasesCount")
    public Result getDiseasesCount(String startYear,String endYear,String[] diseases){
        return  Result.success(emrService.getDiseasesCount(startYear,endYear,diseases));
    }
    @GetMapping("/update")
    public Result update() throws Exception {
        return Result.success(emrService.updateCode());
    }
}

