package com.mc.emr.controller;


import com.mc.emr.common.Result;
import com.mc.emr.service.DrugService;
import com.mc.emr.service.EmrService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author mc
 * @since 2024-04-12
 */
@CrossOrigin
@RestController
@RequestMapping("/emr/drug")
public class DrugController {
    @Resource
    DrugService drugService;
    @GetMapping("/getAllDrug")
    public Result getAllDrug(){
        return Result.success(drugService.getAllDrug());
    }
    @GetMapping("/getDrugCount")
    public Result getDrugCount(){
        return Result.success(drugService.getDrugCount());
    }
}

