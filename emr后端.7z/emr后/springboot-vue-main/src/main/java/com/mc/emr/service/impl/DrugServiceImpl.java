package com.mc.emr.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.mc.emr.entity.Drug;
import com.mc.emr.mapper.DrugMapper;
import com.mc.emr.mapper.EmrMapper;
import com.mc.emr.service.DrugService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author mc
 * @since 2024-04-12
 */
@Service
public class DrugServiceImpl extends ServiceImpl<DrugMapper, Drug> implements DrugService {

    @Resource
    private DrugMapper drugMapper;
    @Override
    public List<Drug> getAllDrug() {
        return drugMapper.selectList(null);
    }

    @Override
    public Integer getDrugCount() {
        return drugMapper.selectCount(null);
    }
}
