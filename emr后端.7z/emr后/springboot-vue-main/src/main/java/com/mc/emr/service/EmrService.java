package com.mc.emr.service;

import com.mc.emr.entity.Emr;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author mc
 * @since 2024-03-23
 */
public interface EmrService extends IService<Emr> {
    List<Emr> getAllEmr() throws Exception;

    List<Emr> getEmrBy(String context,int type,String date,String radio,int flag) throws Exception;

    int saveEmr(Emr emr) throws Exception;

    List<Emr> todayEmr() throws Exception;

    int deleteById(Integer id);

    List<Emr> getPatientEmr(Integer patientId, Integer target) throws Exception;

    int[] getEveryYearCount();

    int[] getEveryMonthCount(int year);

    int[] getDiseasesCount(String startYear, String endYear, String[] diseases);

    int updateCode() throws Exception;
}
