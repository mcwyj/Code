package com.mc.emr;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.mc.emr.mapper")
public class SpringbootFirstPracticeApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootFirstPracticeApplication.class, args);
    }
}
