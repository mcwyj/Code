package com.mc.emr.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mc.emr.entity.BaseEmr;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author mc
 * @since 2024-04-01
 */
public interface BaseemrService extends IService<BaseEmr> {

    int saveBaseEmr(BaseEmr baseEmr, int type);

    int deleteByBaseId(Integer id);
}
